from flask import current_app,jsonify,request,abort
from app import create_app,db
from models import Articles,ArticlesShema

# Create an application instance
app = create_app()

# Define a route to fetch the avaialable articles

@app.route("/articles", methods=["GET"], strict_slashes=False)
def articles():

	articles = Articles.query.all()
	articles_schema=  ArticlesShema(many=True)
	results = articles_schema.dump(articles)

	return jsonify(results)


@app.route("/articles/<id>", methods=["GET"], strict_slashes=False)
def read_one(id):
    # Build the initial query
    articles = (
        Articles.query.filter(Articles.id == id)
        .one_or_none()
    )

    # Did we find a person?
    if articles is not None:

        # Serialize the data for the response
        article_schema = ArticlesShema()
        data = article_schema.dump(articles)
        return data

    # Otherwise, nope, didn't find that person
    else:
        abort(404, f"Director not found for Id: {id}")
    

if __name__ == "__main__":
	app.run(debug=True)